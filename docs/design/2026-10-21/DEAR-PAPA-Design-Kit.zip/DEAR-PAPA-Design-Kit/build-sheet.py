from pathlib import Path
import json, math, shutil, html, re
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from PIL import Image

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
REPO = ROOT / 'imports/renewal-20261020'
A = BASE / 'assets'
OUT = ROOT / 'output/pdf/DEAR-PAPA-Design-Sheet-20261021.pdf'
OUT.parent.mkdir(parents=True, exist_ok=True)
FONT_DIR = REPO / 'node_modules/pretendard/dist/public/static/alternative'
for name, file in [('Regular','Pretendard-Regular.ttf'),('Medium','Pretendard-Medium.ttf'),('Bold','Pretendard-SemiBold.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONT_DIR/file)))
shutil.copyfile(REPO/'node_modules/pretendard/dist/LICENSE.txt', A/'Pretendard-LICENSE.txt')

W, H = 841.89, 595.28
PAPER='#f7f7f2'; SAGE='#e8ede2'; SOFT='#f0f3eb'; IVORY='#eef0e7'
INK='#303a32'; MUTED='#566052'; LOGO='#344b3c'; LINE='#d7ddd0'; FOREST='#48594d'
C=canvas.Canvas(str(OUT),pagesize=(W,H))
C.setTitle('DEAR PAPA | Design Sheet 1.0 | 2026.10.21')
C.setAuthor('DEAR PAPA')
C.setSubject('Approved website design: logo, colors, type, layout, packaging, card, components and motion')
PAGE=0
TEXT_LOG=[]

def rect(x,y,w,h,fill=PAPER,r=0,stroke=None):
    C.setFillColor(HexColor(fill))
    C.setStrokeColor(HexColor(stroke or fill))
    C.setLineWidth(.6)
    if r: C.roundRect(x,H-y-h,w,h,r,fill=1,stroke=bool(stroke))
    else: C.rect(x,H-y-h,w,h,fill=1,stroke=bool(stroke))

def line(x1,y1,x2,y2,color=LINE,width=.7):
    C.setStrokeColor(HexColor(color));C.setLineWidth(width)
    C.line(x1,H-y1,x2,H-y2)

def text(s,x,y,size=11,color=INK,font='Regular'):
    C.setFont(font,size);C.setFillColor(HexColor(color))
    C.drawString(x,H-y-size*.83,s)
    TEXT_LOG.append(s)

def para(s,x,y,w,size=10.5,leading=None,color=MUTED,font='Regular',maxh=None):
    style=ParagraphStyle('body',fontName=font,fontSize=size,leading=leading or size*1.6,
                         textColor=HexColor(color),wordWrap='CJK',spaceAfter=0)
    p=Paragraph(html.escape(s).replace('\n','<br/>'),style)
    _,h=p.wrap(w,H)
    if maxh is not None and h>maxh: raise ValueError(f'Overflow page {PAGE}: {s[:35]} ({h}>{maxh})')
    p.drawOn(C,x,H-y-h);TEXT_LOG.append(s)
    return h

def image(name,x,y,w=None,h=None,fit=True):
    p=A/name
    iw,ih=Image.open(p).size
    if w is None:w=h*iw/ih
    if h is None:h=w*ih/iw
    if fit:
        scale=min(w/iw,h/ih);dw=iw*scale;dh=ih*scale
        x+=(w-dw)/2;y+=(h-dh)/2;w,h=dw,dh
    C.drawImage(str(p),x,H-y-h,w,h,mask='auto')
    return w,h

def logo(x,y,w=105):
    image('logo.png',x,y,w=w)

def start(kicker,title,subtitle=''):
    global PAGE
    PAGE+=1
    rect(0,0,W,H)
    text('DEAR PAPA',44,24,9,LOGO,'Bold')
    text('DESIGN SHEET / 2026.10.21',600,24,8,MUTED)
    line(44,44,W-44,44)
    text(kicker,44,62,9,MUTED,'Medium')
    text(title,44,85,27,INK,'Medium')
    if subtitle: para(subtitle,44,123,W-88,10.2)

def end():
    line(44,H-39,W-44,H-39)
    text('확정 웹 디자인 기준 · 개발 중인 제품 시안 포함',44,H-28,8,MUTED)
    C.setFont('Regular',8);C.setFillColor(HexColor(MUTED))
    C.drawRightString(W-44,18,f'{PAGE:02d} / 10')
    C.showPage()

def label(s,x,y): text(s,x,y,9,MUTED,'Medium')
def rule_item(n,title,body,x,y,w):
    text(n,x,y,10,LOGO,'Medium')
    text(title,x+28,y,14,INK,'Medium')
    h=para(body,x+28,y+27,w-28,10.5)
    return y+27+h+20
def spec(label_,value,x,y,w=350):
    text(label_,x,y,10,MUTED)
    para(value,x+110,y,w-110,10,14,INK,maxh=43)
    line(x,y+39,x+w,y+39)

# 01 / Editorial cover
start('01 / DESIGN DIRECTION','아빠의 매일에, 딸의 마음을.')
logo(48,165,210)
para('매일 쓰는 하나에,\n전하고 싶은 마음을 담다.',48,250,330,25,35,INK,'Regular',maxh=100)
para('크림색 종이와 밝은 세이지, 차분한 포레스트.\n제품을 이해하고, 브랜드에 공감하고,\n자연스럽게 한 줄 편지를 쓰는 흐름.',48,347,330,12,20)
line(48,435,365,435)
text('WEBSITE DESIGN / VERSION 1.0',48,456,9,LOGO,'Medium')
para('최종 로고 간격과 62% 반투명 헤더까지 반영.\n현재 로컬 사이트의 확정 디자인을 기록합니다.',48,480,330,10.5,17)
image('hero.png',422,160,w=368,h=370)
end()

# 02 / Logo
start('02 / BRAND SIGNATURE','하나의 문장처럼 읽히는 로고',
      'd/p 심볼을 첫 글자로 사용하고, 뒤에는 EAR PAPA를 연결합니다. 대문자 D를 중복해서 넣지 않습니다.')
rect(44,164,754,167,SAGE,8)
logo(221,182,400)
label('확정 가로형 로고 · 직접 그린 벡터 도형',62,308)
spec('심볼과 E 간격','모바일 헤더 실측 약 3.9px\n직전 간격에서 약 1.2px 확대',44,356)
spec('글자 처리','승인한 크기·굵기 유지\n축척 0.95 / stroke 1.76316',44,406)
spec('웹 사용 크기','헤더 23px / 데스크톱 25px\n이미지·섹션 23px / 푸터 28px',44,456)
spec('마스터 SVG','viewBox -4 -4 818.69 238',448,356)
spec('공통 색상','#344B3C · 로고 / 표제용 포레스트',448,406)
spec('사용 위치','헤더·히어로·제품·스토리·FAQ·푸터\n편지 카드와 PNG 내보내기에도 공유',448,456)
end()

# 03 / Palette and type
start('03 / COLOR & TYPOGRAPHY','종이의 온도, 초록의 깊이',
      '밝은 배경의 결을 이어 주고, 중요한 문장과 행동에만 짙은 포레스트를 사용합니다.')
swatches=[
 ('Paper','#F7F7F2','기본 배경'),('Sage','#E8EDE2','제품·스토리 배경'),
 ('Soft','#F0F3EB','보조 섹션'),('Ivory','#EEF0E7','푸터'),
 ('Forest','#48594D','주요 버튼·아이콘'),('Logo','#344B3C','브랜드 로고'),
 ('Ink','#303A32','제목·본문'),('Line','#D7DDD0','얇은 구분선')]
for i,(name,color,use) in enumerate(swatches):
    x=44+i*95
    rect(x,168,87,60,color,6,LINE if i<4 else None)
    text(name,x,239,10,INK,'Medium');text(color,x,255,9,MUTED)
    text(use,x,272,8.5,MUTED)
line(44,307,798,307)
text('Pretendard',44,333,23,INK,'Medium')
para('제목과 본문을 연결하는 담백한 산세리프.\n강조는 크기와 여백으로, 굵기는 절제해서 사용.',44,372,340,11,18)
text('아빠의 매일에, 딸의 마음을.',44,438,21,INK)
para('쉼표는 익숙한 갈고리 형태를 사용합니다.\n손글씨: 나눔 펜 스크립트 / 편지 카드 전용.',44,480,350,10.3,17)
spec('히어로 제목','모바일 38~54px / 데스크톱 40~66px',448,334)
spec('섹션 제목','30.4~48px / line-height 1.35',448,384)
spec('본문과 보조','본문 16~17px / 보조 12~14px',448,434)
spec('본문 색상','#566052 / 작은 안내 #626D5D',448,484)
end()

# 04 / Layout
start('04 / RESPONSIVE COMPOSITION','넓게 보아도, 손안에서도 같은 흐름',
      '첫 화면의 집중도를 높이고, 필요한 행동은 해당 콘텐츠 영역에 배치했습니다.')
image('desktop-hero.jpg',44,165,w=483,h=317)
image('mobile-home.jpg',613,159,w=165,h=347)
label('DESKTOP · 1440 × 1000 기준',44,493)
label('MOBILE · 430 × 900 기준',613,516)
para('컨테이너 1240px · 좌우 여백 22~72px · 섹션 상하 64~112px\n히어로 700px 이하 1열 / 제품 소개 800px 이하 1열 / 메뉴 900px 미만 접힘',44,516,545,9.5,15)
end()

# 05 / Product composition
start('05 / PRODUCT & PACKAGING','용기와 단상자, 하나의 선물',
      '연한 딥그린 용기와 슬림한 무광 단상자. 색감과 제품명은 맞추고, 소재의 차이는 자연스럽게 남깁니다.')
image('hero.png',44,167,w=290,h=309)
image('gallery.png',376,167,w=204,h=194)
text('기준 01 / 메인 구성',44,490,12,INK,'Medium')
para('용기 왼쪽 · 단상자 오른쪽. 두 실루엣을 중앙에 정렬하고\n바닥선을 맞춥니다. 단상자는 화면상 약 8% 더 높습니다.',44,512,325,9.5,15)
text('기준 02 / 제품 뷰어',376,384,12,INK,'Medium')
para('용기 / 단상자 두 가지 탭.\n좌측 상단 공통 로고, 우측 상단 ‘디자인 시안’.\n250ms 전환에서도 동일한 세이지 배경을 유지합니다.',376,408,400,10.5,17)
para('이미지 배경: #E8EDE2 / 모서리: 8px\n제품 인쇄 로고는 기존 상태 유지.\n기획 비례를 보여 주는 웹 시안이며, 제조 치수는 별도 확정합니다.',376,479,405,10.2,17)
end()

# 06 / Content and flow
start('06 / STORY & MESSAGE','이해에서 공감으로, 공감에서 편지로',
      '페이지 순서: 첫 화면 → 제품 → 브랜드 이야기 → 편지 쓰기 → 선물의 의미 → FAQ → 소식 → 푸터')
rect(44,166,354,367,SAGE,8)
logo(64,186,83)
text('디어파파가 시작된 마음',64,225,10,MUTED)
para('늘 우리를 챙겼던 아빠.\n이번엔 우리가\n챙길 차례.',64,252,310,23,32,INK,maxh=110)
para('DEAR PAPA는 딸이 아빠에게 건네는 한 줄 편지에서 시작했습니다.',64,370,310,10.5,17)
para('매일 바르는 스킨케어에 마음을 담은 짧은 편지를 더해, 평소에 하지 못한 말을 선물과 함께 전할 수 있도록 준비하고 있습니다.',64,418,310,10.5,17,maxh=80)
text('내 마음도 한 줄 남기기  →',64,501,10,FOREST,'Medium')
text('왜 올인원에, 편지를 더할까요?',435,177,21,INK,'Medium')
y=rule_item('01','매일 쓰일 선물','받는 순간을 넘어, 아빠의 일상에서 손이 가는 스킨케어.',435,227,355)
y=rule_item('02','간편한 하나','여러 단계의 순서를 고민하지 않도록 세안 후 하나로.',435,y,355)
y=rule_item('03','선물을 고른 마음','짧은 편지가 ‘아빠를 생각하며 골랐다’는 마음을 전합니다.',435,y,355)
line(435,475,790,475)
para('제품 제목: ‘매일의 마음을, 하나에 담아.’\n‘아빠에게 편지 쓰기’는 편지 영역에,\n‘레터 올인원 만나보기’는 제품 영역에 배치.',435,491,355,10,16)
end()

# 07 / Letter card
start('07 / LETTER EXPERIENCE','편지 한 장도 같은 브랜드의 얼굴',
      '밝은 종이, 세이지 테두리, 포레스트 잉크. 제품과 카드가 하나의 선물로 이어지도록 구성했습니다.')
rect(44,165,320,367,SAGE,8)
image('card.png',86,190,w=235,h=294)
label('실제 편지 미리보기 · 예시 문장',87,505)
spec('카드 비율','4:5 / PNG 1080 × 1350px',410,171,385)
spec('종이와 테두리','종이 #FCFAF6 / 테두리 #B6C5AC\n잉크 #2E4536 / 뒷면 #A5B39E',410,223,385)
spec('입력 규격','본문 최대 150자 / 보내는 사람 12자\n긴 문장은 단계적으로 글자 크기 조정',410,275,385)
spec('현재 기능','시작 문장 · 미리보기 · PNG 저장\n보관함 · 지원 환경에서 공유',410,327,385)
para('가입 없이 이 기기의 브라우저에 보관합니다.\n편지는 서버로 전송하지 않습니다.',410,393,375,11,18)
line(410,445,795,445)
para('출시 후 계획\n주문 시 확인한 편지를 손글씨 스타일 서체로 인쇄한 카드에 담아 제품과 함께 보내는 구성. 사람이 직접 손으로 쓰는 카드는 아닙니다.',410,463,375,10.5,17,maxh=75)
end()

# 08 / UI
start('08 / COMPONENTS & SURFACES','선명한 조작, 부드러운 배경',
      '배경은 8px 라운딩으로 통일하고, 버튼·입력창·제품 형태는 각자의 기존 규격을 유지합니다.')
image('header-detail.png',44,165,w=345,h=216)
text('스크롤 헤더 / 은은한 반투명',44,400,15,INK,'Medium')
para('78px 고정 높이 · 크림색 불투명도 62%\nblur(16px) · saturate(1.05) · 180ms 전환\n처음에는 단색, 스크롤하면 아래 내용이 부드럽게 비칩니다.',44,431,350,10.5,18)
para('로고와 메뉴는 선명하게 유지합니다.\n투명도 감소 설정과 블러 미지원 환경에서는 단색 배경.',44,501,350,9.5,15)
rect(434,168,176,48,FOREST,4)
text('아빠에게 편지 쓰기',453,185,12,'#F4EDE3','Medium')
text('레터 올인원 만나보기  →',434,244,12,INK,'Medium')
line(434,265,598,265,INK)
rect(434,292,82,25,'#e1e7dc',12)
text('출시 준비 중',445,299,10,INK)
line(434,342,798,342)
text('궁금한 이야기 / FAQ',434,360,13,INK,'Medium')
para('얇은 구분선과 + / − 아이콘.\n열기 전에도 제목과 제품의 확정 상태를 읽을 수 있습니다.',434,385,357,10.5,17)
line(434,437,798,437)
text('공식 채널',434,454,13,INK,'Medium')
para('Instagram · Naver Blog · YouTube · Facebook\n모두 포레스트 단색 로고와 실제 공식 페이지 링크.\n문의: hello@dearpapa.kr',434,480,357,10.5,17)
end()

# 09 / Motion
start('09 / MOTION LANGUAGE','천천히 이해하고, 가볍게 이어지는 움직임',
      '스크롤에 따라 한 번 등장하고 멈춥니다. 로고의 회전은 브랜드의 의미를 보여 주는 짧은 장면입니다.')
rect(44,165,754,104,SAGE,8)
for x,angle,word in [(90,0,'Dear'),(273,90,'180° 회전'),(463,180,'Papa')]:
    C.saveState();C.translate(x+27,H-208);C.rotate(-angle)
    # The d is built from the same ring and upper stem as the live logo.
    C.drawImage(str(A/'dear.png'),-31,-31,62,62,mask='auto')
    C.restoreState();text(word,x-4,244,10,INK,'Medium')
logo(634,188,123);text('합쳐진 로고로 복귀',619,244,10,INK,'Medium')
for x in [202,395,582]: text('→',x,205,18,MUTED)
rows=[
 ('텍스트 등장','560ms','10px 위로 · opacity .72 → 1'),
 ('이미지 등장','680ms','14px 위로 · opacity .80 → 1'),
 ('행동 링크 등장','420ms','6px 위로 · 최대 지연 150ms'),
 ('로고 회전','3.8s','0° → 180° · 히어로 시작 전 0.5s 여유'),
 ('제품 전환','250ms','같은 배경 위 opacity 전환 · 사각 번쩍임 방지'),
 ('카드 피드백','900ms / 1s','잉크 등장 / 보관 시 뒤집힘'),
]
for i,(a,b,d) in enumerate(rows):
    yy=293+i*34
    text(a,52,yy,10.5,INK,'Medium');text(b,232,yy,10.5,LOGO)
    text(d,371,yy,10.2,MUTED);line(44,yy+25,798,yy+25)
para('반복 규칙: 히어로·푸터 로고는 진입 시 한 번. 푸터는 눌러서 다시 보기 가능.\n모션 줄이기 설정을 존중하며, 키보드 탐색은 장식 모션을 기다리지 않도록 처리합니다.',44,514,754,9.4,14)
end()

# 10 / Implementation
start('10 / HANDOFF & APPROVED STATE','이 상태를 다음 작업의 기준으로',
      '최종 디자인, 원본 자산, 코드의 적용 값을 함께 전달합니다. 웹사이트 자체는 추가 변경하지 않았습니다.')
x1,x2=44,443
text('함께 제공하는 파일',x1,174,16,INK,'Medium')
items=[
 ('공유용 PDF','브랜드·화면·콘텐츠·컴포넌트·모션 10쪽'),
 ('웹 디자인 시트','원본 화면 확대 / 로고 회전·헤더 블러 체험'),
 ('벡터와 이미지','확정 로고 SVG · 제품 시안 · 현재 화면 캡처'),
 ('디자인 값','design-tokens.json / CSS 변수 / 원본 해시 목록'),
]
y=211
for h,b in items:
    text(h,x1,y,11,INK,'Medium');para(b,x1,y+21,350,10,16);y+=66
text('최종 적용 상태',x2,174,16,INK,'Medium')
para('유지\n통합 가로 로고와 최신 간격, 밝은 세이지 배경,\n용기·단상자 중앙 정렬, 62% 헤더, 자연스러운 모션.',x2,211,350,10.5,18)
para('화면에서 제외\n링컨 사진·설명·성분 문자 효과, 헤더 편지 버튼,\n첫 화면의 중복 CTA, 제품 뷰어의 메시지 카드 탭.',x2,290,350,10.5,18)
para('제품에 인쇄된 로고\n용기와 단상자의 상·하단 인쇄는 기존 상태 유지.\n이미지 좌측 상단과 웹 UI에만 확정 가로 로고 사용.',x2,369,350,10.5,18)
line(44,472,798,472)
para('보존 기준\n9개 페이지 주소, 공식 문장과 facts 본문, 메타·10개 JSON-LD·9개 루트 파일 유지.\n기준 시트는 로컬 미리보기 디자인이며, 제품 가격·전성분·출시일은 아직 확정되지 않았습니다.',44,489,750,9.8,16)
end()
C.save()
(BASE/'pdf-text-source.txt').write_text('\n\n'.join(TEXT_LOG),encoding='utf-8')
print(f'Created {OUT} ({PAGE} pages)')
