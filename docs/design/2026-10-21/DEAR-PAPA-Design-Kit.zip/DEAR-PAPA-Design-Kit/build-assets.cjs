const fs = require('node:fs/promises');
const path = require('node:path');
const { createRequire } = require('node:module');
const { createHash } = require('node:crypto');
const repo = path.resolve(__dirname, '../../imports/renewal-20261020');
const sharp = createRequire(path.join(repo, 'package.json'))('sharp');
const assets = path.join(__dirname, 'assets');
async function main() {
  const copies = {
    'logo.svg': 'public/logo-horizontal.svg',
    'bottle.webp': 'public/images/letter-all-in-one-deep-green-logo-v4.webp',
    'carton.webp': 'public/images/letter-all-in-one-carton-sage-v1.webp',
    'Pretendard-Regular.woff2': 'node_modules/pretendard/dist/web/static/woff2/Pretendard-Regular.woff2',
    'Pretendard-SemiBold.woff2': 'node_modules/pretendard/dist/web/static/woff2/Pretendard-SemiBold.woff2',
  };
  for (const [to, from] of Object.entries(copies)) await fs.copyFile(path.join(repo, from), path.join(assets, to));
  await sharp(path.join(assets, 'logo.svg'), { density: 300 }).png().toFile(path.join(assets, 'logo.png'));
  const rects = JSON.parse(await fs.readFile(path.join(assets, 'mobile-rects.json'), 'utf8'));
  for (const [name, r] of Object.entries(rects)) {
    if (!r) continue;
    await sharp(path.join(assets, 'mobile-full.png')).extract({
      left: Math.floor(r.x), top: Math.ceil(r.y),
      width: Math.floor(r.width), height: Math.floor(r.height) - 1,
    }).png().toFile(path.join(assets, `${name}.png`));
  }
  const slices = {
    'flow-hero': [78, 925], 'flow-product': [1001, 930],
    'flow-story': [2941, 930], 'flow-letter': [3544, 930],
    'flow-meaning': [5477, 930], 'flow-faq': [6535, 930],
    'flow-footer': [7853, 930], 'composer': [4370, 850],
  };
  for (const [name, [top, height]] of Object.entries(slices)) {
    await sharp(path.join(assets, 'mobile-full.png'))
      .extract({ left: 0, top, width: 415, height }).png().toFile(path.join(assets, `${name}.png`));
  }
  await sharp(path.join(assets, 'desktop-full.jpg')).extract({left:0,top:0,width:1425,height:935})
    .jpeg({quality:92}).toFile(path.join(assets,'desktop-hero.jpg'));
  await sharp(path.join(assets,'header-glass.jpg')).extract({left:0,top:0,width:415,height:260})
    .png().toFile(path.join(assets,'header-detail.png'));
  // Derive the approved monogram from the same artwork, not a replacement font.
  const svg = await fs.readFile(path.join(assets,'logo.svg'),'utf8');
  const paths = [...svg.matchAll(/<path\b[^>]*\/>/g)].slice(0,2).map(m=>m[0]).join('');
  await fs.writeFile(path.join(assets,'mark.svg'), `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-4 -4 142 238"><g fill="#344b3c">${paths}</g></svg>`);
  await sharp(path.join(assets,'mark.svg'),{density:300}).png().toFile(path.join(assets,'mark.png'));
  const dear = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256"><g fill="#344b3c"><path fill-rule="evenodd" d="M68 128a60 60 0 1 0 120 0a60 60 0 1 0 -120 0zM88 128a40 42 0 1 0 80 0a40 42 0 1 0 -80 0z"/><path d="M168 24h20v162h-20z"/></g></svg>';
  await fs.writeFile(path.join(assets,'dear.svg'),dear);
  await sharp(Buffer.from(dear),{density:300}).png().toFile(path.join(assets,'dear.png'));
  const css = await fs.readFile(path.join(repo,'app/globals.css'),'utf8');
  const root = css.match(/:root\s*\{([\s\S]*?)\n\}/)[1];
  const tokens = Object.fromEntries([...root.matchAll(/(--[\w-]+):\s*([^;]+);/g)].map(m=>[m[1],m[2].trim()]));
  await fs.writeFile(path.join(__dirname,'design-tokens.json'), JSON.stringify({
    version:'1.0',date:'2026-10-21',status:'Approved local website design',
    tokens,
    logo:{viewBox:'-4 -4 818.69 238',wordmarkTranslateX:172.69,wordmarkScale:.95,strokeWidth:1.76316,headerGapApproxPx:3.86},
    header:{height:78,scrolledOpacity:.62,blur:16,saturation:1.05,transitionMs:180},
    hero:{baselinePercent:10.55,bottleLeftPercent:31,cartonLeftPercent:69,imageHeightPercent:88,cartonVisibleHeightRatio:1.0759},
    card:{exportWidth:1080,exportHeight:1350,maxChars:150,maxFrom:12,paper:'#fcfaf6',ink:'#2e4536',frame:'#b6c5ac',back:'#a5b39e'},
  },null,2));
  await fs.writeFile(path.join(assets,'design-tokens.css'), `:root {${root}\n}\n`);
  const sources = ['components/Logo.tsx','public/logo-horizontal.svg','app/globals.css',
    'components/SiteHeader.module.css','components/home/Hero.module.css','components/home/Product.module.css',
    'components/home/HeroLogo.module.css','components/FooterLogo.module.css','components/RevealObserver.tsx',
    'components/letter/LetterCard.module.css','components/letter/card.ts','lib/facts.ts','PRESERVATION.md'];
  const manifest = [];
  for(const file of sources) {
    const data = await fs.readFile(path.join(repo,file));
    manifest.push({file,sha256:createHash('sha256').update(data).digest('hex')});
    const dest=path.join(__dirname,'implementation',file);
    await fs.mkdir(path.dirname(dest),{recursive:true});
    await fs.writeFile(dest,data);
  }
  await fs.writeFile(path.join(__dirname,'source-manifest.json'),JSON.stringify({date:'2026-10-21',repo:'imports/renewal-20261020',files:manifest},null,2));
  console.log('Prepared current screenshots, logo, product assets, tokens and source manifest.');
}
main().catch(e=>{console.error(e);process.exitCode=1;});
