from pathlib import Path
import shutil, re, json

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
A=BASE/'assets'
labels=['디자인 방향','확정 로고','컬러와 서체','반응형 배치','제품과 단상자','스토리와 문구','편지 카드','컴포넌트와 배경','모션 기준','인계와 적용 상태']
for i in range(1,11):
    shutil.copyfile(ROOT/f'tmp/pdfs/design-sheet/page-{i:02d}.png', A/f'sheet-{i:02d}.png')
shutil.copyfile(ROOT/'output/pdf/DEAR-PAPA-Design-Sheet-20261021.pdf', BASE/'DEAR-PAPA-Design-Sheet.pdf')
svg=(A/'logo.svg').read_text(encoding='utf-8')
svg=re.sub(r' width="[^"]*" height="[^"]*"','',svg,count=1)
paths=list(re.finditer(r'<path\b[^>]*\/>',svg))
motion='''<g transform="translate(-75.19 -26.54) scale(1.105769)">
  <path class="papa" d="M68 70h20v162h-20z"/>
  <path class="restore" d="M168 24h20v162h-20z"/>
  <g class="turn"><path fill-rule="evenodd" d="M68 128a60 60 0 1 0 120 0a60 60 0 1 0 -120 0zM88 128a40 42 0 1 0 80 0a40 42 0 1 0 -80 0z"/><path d="M168 24h20v162h-20z"/></g>
</g>'''
animated=svg[:paths[0].start()]+motion+svg[paths[1].end():]
nav=''.join(f'<a href="#sheet-{i:02d}"><span>{i:02d}</span>{name}</a>' for i,name in enumerate(labels,1))
sheets=''.join(f'''<section class="sheet" id="sheet-{i:02d}" aria-labelledby="title-{i:02d}">
  <div class="sheet-meta"><h2 id="title-{i:02d}">{i:02d} / {name}</h2><a href="assets/sheet-{i:02d}.png" target="_blank" rel="noopener">크게 보기 ↗</a></div>
  <img src="assets/sheet-{i:02d}.png" alt="{name} 디자인 기준, PDF {i}쪽" width="1500" height="1061" loading="lazy">
</section>''' for i,name in enumerate(labels,1))
flow=''.join(f'<figure><img src="assets/flow-{key}.png" alt="{name} 현재 모바일 화면" loading="lazy"><figcaption>{name}</figcaption></figure>'
 for key,name in [('hero','첫 화면'),('product','제품'),('story','이야기'),('letter','편지'),('meaning','선물의 의미'),('faq','FAQ'),('footer','푸터')])
page='''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>DEAR PAPA · 확정 디자인 시트</title>
<link rel="icon" href="assets/mark.svg" type="image/svg+xml">
<link rel="stylesheet" href="assets/design-tokens.css">
<style>
@font-face{font-family:Sheet;src:url('assets/Pretendard-Regular.woff2') format('woff2');font-weight:400;font-display:swap}
@font-face{font-family:Sheet;src:url('assets/Pretendard-SemiBold.woff2') format('woff2');font-weight:600;font-display:swap}
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:100px}body{margin:0;background:var(--paper);color:var(--ink);font-family:Sheet,sans-serif}
a{color:inherit;text-underline-offset:5px}button{font:inherit;cursor:pointer}button:focus-visible,a:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--logo);outline-offset:4px}
.top{position:sticky;top:0;z-index:30;display:flex;align-items:center;justify-content:space-between;height:76px;padding:0 4vw;background:rgb(247 247 242 / .9);backdrop-filter:blur(16px);border-bottom:1px solid var(--line)}
.top img{height:27px;width:auto}.top nav{display:flex;gap:24px;font-size:13px}.top a{text-decoration:none}
.intro{max-width:1360px;margin:0 auto;padding:70px 4vw 60px;display:grid;grid-template-columns:1.1fr 1fr;gap:70px;align-items:center}
.eyebrow{font-size:12px;color:var(--ink-2);letter-spacing:.08em;margin-bottom:24px}
h1{font-weight:400;font-size:clamp(34px,4vw,58px);line-height:1.2;letter-spacing:-.04em;margin:0 0 24px}
.intro p{font-size:16px;line-height:1.9;color:var(--ink-2);max-width:35em}.intro .hero{width:100%;border-radius:8px}
.composition{position:relative;aspect-ratio:1/1.06;background:var(--sage);overflow:hidden;isolation:isolate}.composition-brand{position:absolute;left:22px;top:20px;z-index:3;display:grid;gap:3px}.composition-brand img{height:23px;width:auto}.composition-brand span{font-size:12px;color:var(--ink-2)}.composition .bottle{position:absolute;left:31%;bottom:4%;height:88%;width:auto;max-width:none;transform:translateX(-55.04%);mix-blend-mode:multiply;z-index:2}.composition .carton{position:absolute;left:69%;bottom:7.11%;height:88%;width:auto;max-width:none;transform:translateX(-53.714%)}.composition .caption{position:absolute;left:15px;right:15px;bottom:14px;font-size:10px;color:var(--ink-2);text-align:right}
.actions{display:flex;flex-wrap:wrap;gap:12px;margin-top:30px}.button{display:inline-flex;align-items:center;justify-content:center;min-height:48px;padding:12px 23px;background:var(--forest);color:var(--ink-inverse);border:1px solid var(--forest);border-radius:4px;text-decoration:none;font-size:14px}
.button.ghost{background:transparent;color:var(--ink);border-color:var(--line-strong)}
.facts{display:flex;flex-wrap:wrap;gap:24px;margin-top:30px;padding-top:22px;border-top:1px solid var(--line);color:var(--ink-2);font-size:12px}
.workspace{max-width:1440px;padding:0 4vw;margin:0 auto;display:grid;grid-template-columns:185px minmax(0,1fr);gap:30px}
.toc{position:sticky;top:98px;align-self:start;display:grid;gap:1px}.toc a{padding:11px 4px;text-decoration:none;font-size:13px;display:flex;gap:14px;color:var(--ink-2)}.toc a:hover{color:var(--ink);background:var(--sage)}.toc span{font-size:10px;line-height:17px;color:var(--ink-3)}
.sheet{margin-bottom:42px;scroll-margin-top:94px}.sheet-meta{display:flex;align-items:center;justify-content:space-between;gap:20px;margin-bottom:12px}.sheet-meta h2{font-size:15px;font-weight:600;margin:0}.sheet-meta a{font-size:12px;color:var(--ink-2)}.sheet>img{display:block;width:100%;height:auto;border:1px solid var(--line);border-radius:8px}
.extras{max-width:1280px;margin:30px auto 0;padding:60px 4vw;border-top:1px solid var(--line)}.extras h2{font-size:32px;font-weight:400;letter-spacing:-.03em;margin:0 0 18px}.extras>p{color:var(--ink-2);font-size:15px;line-height:1.8}
.demos{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-top:32px}.demo{border-radius:8px;background:var(--sage);padding:28px;min-width:0}.demo h3{font-size:18px;font-weight:600;margin:0 0 12px}.demo p{font-size:13px;line-height:1.8;color:var(--ink-2)}
.logo-stage{display:grid;place-items:center;height:200px}.logo-stage svg{width:75%;max-height:110px;overflow:visible}.turn{transform-box:view-box;transform-origin:128px 128px}.restore{opacity:0}
.playing .turn{animation:turn 3.8s cubic-bezier(.65,0,.35,1) .5s both}.playing .papa{animation:papa 3.8s ease .5s both}.playing .restore{animation:restore 3.8s ease .5s both}
@keyframes turn{0%,26%{transform:rotate(0)}68%,100%{transform:rotate(180deg)}}@keyframes papa{0%,8%{opacity:1}22%,100%{opacity:0}}@keyframes restore{0%,78%{opacity:0}94%,100%{opacity:1}}
.glass-demo{height:245px;overflow:auto;background:var(--paper);border:1px solid var(--line);border-radius:8px;position:relative;margin-top:20px}.glass-bar{height:64px;position:sticky;top:0;z-index:1;padding:17px 18px;display:flex;justify-content:space-between;align-items:center;background:rgb(247 247 242 / .62);backdrop-filter:blur(16px) saturate(1.05);-webkit-backdrop-filter:blur(16px) saturate(1.05);border-bottom:1px solid var(--line)}
.glass-bar img{height:23px;width:auto}.hamburger{width:20px;height:10px;border-top:1px solid var(--ink);border-bottom:1px solid var(--ink)}.glass-demo>.glass-content{display:block;width:100%}
.flow{display:flex;overflow-x:auto;gap:18px;padding:20px 0;scroll-snap-type:x mandatory}.flow figure{margin:0;flex:0 0 190px;scroll-snap-align:start}.flow img{width:190px;display:block;border-radius:8px;border:1px solid var(--line)}figcaption{font-size:13px;margin-top:12px;color:var(--ink-2)}
.downloads{display:flex;flex-wrap:wrap;gap:12px;margin-top:24px}.downloads a{font-size:13px;padding:13px 18px;border:1px solid var(--line-strong);border-radius:4px;text-decoration:none}
.foot{margin-top:30px;background:var(--ivory);padding:36px 4vw;display:flex;flex-wrap:wrap;justify-content:space-between;gap:18px;color:var(--ink-2);font-size:12px;line-height:1.8}
@media(max-width:900px){.intro{gap:30px}.workspace{grid-template-columns:1fr}.toc{position:static;display:flex;overflow:auto;padding-bottom:12px}.toc a{flex:0 0 auto}.top nav{gap:16px}}
@media(max-width:640px){.intro{grid-template-columns:1fr;padding-top:40px}.intro .hero{max-width:430px}.demos{grid-template-columns:1fr}.top{height:68px}.top img{height:23px}.top nav{font-size:12px;gap:14px}.top nav a:first-child{display:none}.intro p{font-size:14px}.sheet-meta h2{font-size:13px}.extras h2{font-size:27px}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}.playing .turn,.playing .papa,.playing .restore{animation:none}.restore{opacity:0}}
@media(prefers-reduced-transparency:reduce){.top,.glass-bar{background:var(--paper);backdrop-filter:none;-webkit-backdrop-filter:none}}
@media print{.top,.toc,.actions,.extras,.foot{display:none}.workspace{display:block;padding:0}.sheet{break-after:page}.sheet-meta{display:none}.intro{display:none}}
</style></head><body>
<header class="top"><a href="#top" aria-label="디자인 시트 처음으로"><img src="assets/logo.svg" alt="DEAR PAPA"></a><nav aria-label="디자인 시트 메뉴"><a href="#sheets">디자인 기준</a><a href="#motion">모션 보기</a><a href="DEAR-PAPA-Design-Sheet.pdf" download>PDF 저장 ↓</a></nav></header>
<main id="top">
<section class="intro"><div><div class="eyebrow">APPROVED DESIGN · 2026.10.21 · V1.0</div><h1>매일의 마음을,<br>하나에 담아.</h1><p>디어파파가 함께 다듬어 온 디자인을 한곳에 모았습니다.<br>로고의 작은 간격부터 제품의 균형, 배경의 온도와 움직임까지.<br>다음 작업에서도 이어 쓸 수 있는 확정 기준입니다.</p><div class="actions"><a class="button" href="DEAR-PAPA-Design-Sheet.pdf" download>디자인 시트 PDF 저장</a><a class="button ghost" href="#motion">움직임 확인하기</a></div><div class="facts"><span>10쪽 디자인 기준</span><span>현재 화면 캡처</span><span>벡터 · 디자인 값 · 원본 코드</span></div></div><div class="hero composition"><div class="composition-brand"><img src="assets/logo.svg" alt="DEAR PAPA"><span>Letter All-in-One</span></div><img class="bottle" src="assets/bottle.webp" alt="연한 딥그린 용기 디자인 시안"><img class="carton" src="assets/carton.webp" alt="용기보다 높게 배치한 단상자 디자인 시안"><span class="caption">용기와 단상자는 개발 중인 디자인 시안입니다.</span></div></section>
<div class="workspace" id="sheets"><nav class="toc" aria-label="시트 목차">__NAV__</nav><div>__SHEETS__</div></div>
<section class="extras" id="motion"><div class="eyebrow">LIVE DETAILS</div><h2>느낌까지 확인하는 두 장면</h2><p>현재 웹사이트의 로고 회전과 반투명 헤더 값을 그대로 사용한 체험입니다.</p>
<div class="demos"><article class="demo"><h3>d(Dear)에서 p(Papa)로</h3><p>0.5초의 여유 뒤, 3.8초 동안 회전하고 합쳐진 로고로 돌아옵니다.</p><div class="logo-stage" id="motion-logo">__ANIMATED__</div><button class="button" id="replay" type="button">로고 모션 다시 보기</button><p id="motion-status" role="status">한 번 재생한 뒤 멈춥니다.</p></article>
<article class="demo"><h3>스크롤 아래로 비치는 크림색</h3><p>아래 창 안에서 스크롤해 보세요. 불투명도 62%, 블러 16px.</p><div class="glass-demo" tabindex="0" aria-label="반투명 헤더 스크롤 체험"><div class="glass-bar"><img src="assets/logo.svg" alt="DEAR PAPA"><span class="hamburger" aria-hidden="true"></span></div><img class="glass-content" src="assets/hero.png" alt="헤더 아래로 지나가는 용기와 단상자"><img class="glass-content" src="assets/story.png" alt="헤더 아래로 지나가는 브랜드 이야기"></div></article></div></section>
<section class="extras" id="flow"><div class="eyebrow">MOBILE JOURNEY</div><h2>첫 화면에서 마지막까지</h2><p>최신 로고와 전체 배치가 반영된 실제 모바일 화면입니다. 가로로 넘겨 확인하세요.</p><div class="flow">__FLOW__</div><div class="downloads"><a href="assets/mobile-full.png" target="_blank" rel="noopener">모바일 전체 화면 ↗</a><a href="assets/desktop-full.jpg" target="_blank" rel="noopener">데스크톱 전체 화면 ↗</a><a href="assets/logo.svg" download>확정 로고 SVG ↓</a><a href="design-tokens.json" download>디자인 값 JSON ↓</a></div></section>
</main><footer class="foot"><div>DEAR PAPA · 디자인 기준 V1.0<br>로컬 미리보기 기준. 용기·상자·카드는 개발 중인 시안입니다.</div><div>2026.10.21<br>hello@dearpapa.kr</div></footer>
<script>
const stage=document.getElementById('motion-logo'),button=document.getElementById('replay'),status=document.getElementById('motion-status');
let timer;
button.addEventListener('click',()=>{
 clearTimeout(timer);
 if(matchMedia('(prefers-reduced-motion: reduce)').matches){status.textContent='기기의 모션 줄이기 설정에 따라 정지된 로고로 표시합니다.';return;}
 stage.classList.remove('playing');void stage.offsetWidth;stage.classList.add('playing');
 status.textContent='Dear에서 Papa로, 그리고 하나의 로고로.';
 timer=setTimeout(()=>{stage.classList.remove('playing');status.textContent='재생이 끝났습니다.';},4350);
});
</script></body></html>'''
page=page.replace('__NAV__',nav).replace('__SHEETS__',sheets).replace('__FLOW__',flow).replace('__ANIMATED__',animated)
(BASE/'index.html').write_text(page,encoding='utf-8')
(BASE/'README.md').write_text('''# DEAR PAPA 디자인 시트

2026.10.21 · V1.0 · 확정 로컬 웹 디자인 기준

- `DEAR-PAPA-Design-Sheet.pdf`: 공유 및 인쇄용 10쪽 디자인 기준.
- `index.html`: 로컬에서 열 수 있는 웹 시트. PDF 페이지, 최신 모바일/데스크톱 화면, 로고 회전 및 반투명 헤더 체험.
- `assets/logo.svg`: 최신 간격을 반영한 가로형 벡터. `mark.svg`는 기존 단독 심볼.
- `assets/bottle.webp`, `assets/carton.webp`: 현재 사이트에 사용하는 제품 시안. 인쇄 로고는 기존 상태.
- `design-tokens.json`, `assets/design-tokens.css`: 현재 색상·서체·간격·동작 수치.
- `implementation/`: 관련 소스 스냅샷. `source-manifest.json`에 SHA-256 기록.
- `build-assets.cjs`, `build-sheet.py`, `build-web.py`: 생성 과정의 원본 스크립트. 재생성은 원 프로젝트와 ReportLab/Pillow 환경을 사용합니다.

## 범위

이번 시트는 최종 채택된 웹 디자인을 기록합니다. 링컨 사진과 문자 효과, 거절한 일러스트,
교체를 취소한 제품 인쇄 로고 시안은 적용안에 포함하지 않았습니다.
제품 가격, 전성분, 출시일은 아직 미정이며 제품·포장·카드 이미지는 개발 중인 시안입니다.
웹 시트의 체험 영역은 문서 내부 데모이며 운영 사이트를 수정하거나 데이터를 전송하지 않습니다.

## 파일 사용

PDF는 그대로 공유할 수 있습니다. 웹 시트는 폴더 구조를 유지한 채 `index.html`을 여세요.
로고는 폰트가 아닌 벡터 도형이며 `EAR PAPA` 앞에 대문자 D를 추가하지 않습니다.
Pretendard 폰트 라이선스는 `assets/Pretendard-LICENSE.txt`에 있습니다.
나눔 펜 스크립트는 현재 화면 캡처에 포함되며 원본 폰트 파일은 이 번들에 재배포하지 않습니다.
''',encoding='utf-8')
print('Created interactive web design sheet.')
