# DEAR PAPA 디자인 시트

2026.10.21 · V1.0 · 확정 로컬 웹 디자인 기준

- `DEAR-PAPA-Design-Sheet.pdf`: 공유 및 인쇄용 10쪽 디자인 기준.
- `index.html`: 로컬에서 열 수 있는 웹 시트. PDF 페이지, 최신 모바일/데스크톱 화면, 로고 회전 및 반투명 헤더 체험.
- `assets/logo.svg`: 최신 간격을 반영한 가로형 벡터. `mark.svg`는 기존 단독 심볼.
- `assets/bottle.webp`, `assets/carton.webp`: 현재 사이트에 사용하는 제품 시안. 인쇄 로고는 기존 상태.
- `design-tokens.json`, `assets/design-tokens.css`: 현재 색상·서체·간격·동작 수치.
- `implementation/`: 관련 소스 스냅샷. `source-manifest.json`에 SHA-256 기록.
- `build-assets.cjs`, `build-sheet.py`, `build-web.py`: 생성 과정의 원본 스크립트. 재생성은 원 프로젝트와 ReportLab/Pillow 환경을 사용합니다.

## 범위

이번 시트는 최종 채택된 웹 디자인을 기록합니다. 링컨 사진과 문자 효과, 거절한 일러스트,
교체를 취소한 제품 인쇄 로고 시안은 적용안에 포함하지 않았습니다.
제품 가격, 전성분, 출시일은 아직 미정이며 제품·포장·카드 이미지는 개발 중인 시안입니다.
웹 시트의 체험 영역은 문서 내부 데모이며 운영 사이트를 수정하거나 데이터를 전송하지 않습니다.

## 파일 사용

PDF는 그대로 공유할 수 있습니다. 웹 시트는 폴더 구조를 유지한 채 `index.html`을 여세요.
로고는 폰트가 아닌 벡터 도형이며 `EAR PAPA` 앞에 대문자 D를 추가하지 않습니다.
Pretendard 폰트 라이선스는 `assets/Pretendard-LICENSE.txt`에 있습니다.
나눔 펜 스크립트는 현재 화면 캡처에 포함되며 원본 폰트 파일은 이 번들에 재배포하지 않습니다.
